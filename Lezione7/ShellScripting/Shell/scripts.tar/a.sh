#!/bin/bash
cd /home/vicini/DY/CC/NNLO/
./fewzw 14002 LHCres14002.dat vegas_last_iter_14002 > LHCout14002.out
