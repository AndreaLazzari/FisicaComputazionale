#!/bin/bash
echo hallo
