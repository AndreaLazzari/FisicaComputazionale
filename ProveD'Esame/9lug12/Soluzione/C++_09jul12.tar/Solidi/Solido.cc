#include "Solido.hh"

Solido::Solido() {
}
