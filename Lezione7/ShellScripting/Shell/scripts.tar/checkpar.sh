#!/bin/bash
if [ "$#" -lt 1 ]
then 
	echo "Usage: $0 <parameter>"
	exit 1
else
        echo "ecco il primo parametro: $1"

fi
