#!/bin/bash
count=1
for arg
do
	echo "Argument $count is $arg"
	count=$((count+1))		
done
exit 0