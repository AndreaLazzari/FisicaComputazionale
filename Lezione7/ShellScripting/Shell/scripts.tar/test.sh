#!/bin/bash
if [ "$#" -lt 1 ]
then
        echo "Usage: $0 <parameter>
        echo "where parameter is: italian|thai|smart|steakhouse"
        exit 1
fi
